import math
import numpy as np
import scipy as sp

import itertools as it
import functools as ft
import operator as op

import matplotlib.pyplot as plt

import gmab_fast
from gmab_fast import set_world
from gmab_fast import vec_rollforward, vec_GMAB, vec_GMAB_ratchet
from gmab_fast import make_portfolio
from gmab_fast import delta, rho
from gmab_fast import value_by_rep, value_by_error, value_by_precision
from gmab_fast import shock_value, write_shock_data, read_shock_data

from ast import literal_eval
import csv

N = 10000

# model params
t_now = 0
t_max = 10 # t in years
dt = 1/252
r = .03 * np.ones(int(t_max/dt))

# equity params
sig2 = .18**2
eZ = None
S0 = 1

# account params
t_begin = 0
t_end = t_max
A_now = 1
A = A_now * np.ones(int(t_max/dt) + 1)
cr = .01  # crediting rate
ec = .045  # expense ratio
rc = .00  # rider charge

# zipped model arguments
world_args = t_now, t_max, dt, r, sig2, eZ, S0

vec_roll_args = t_begin, t_end, A, ec
vec_GMAB_args = t_begin, t_end, A, ec, rc, cr
vec_GMAB_ratchet_args = t_begin, t_end, A, ec, rc, cr


'''scrape some data'''

N = 100000

shocks = list()
for dS in range(-15,16): # remember to sample by multiplicative changes
  for dr in range(-20,21,2):
    shocks.append((dS/100,dr/10000))


for count in range(2,6):
  world, ignore = read_shock_data('sample{}_delta_.csv'.format(count))

  temp = shock_value(world, shocks, value_by_rep, 100000, vec_GMAB_ratchet, *vec_GMAB_ratchet_args)

  write_shock_data(world, temp, 'sample{}_.csv'.format(count))

  # make new world state
#  t_now, t_max, dt, r, sig2, eZ, S0 = world_args
#  t_now = np.random.random() * t_max
#  world = t_now, t_max, dt, r, sig2, eZ, S0
#  world = set_world(world)

#  for greek in {delta, rho}:
#    temp = shock_value(world, shocks, value_by_rep, 100000, greek, .001, vec_GMAB_ratchet, *vec_GMAB_ratchet_args)

#    write_shock_data(world, temp, 'sample{}_{}.csv'.format(count, temp[0][1]))
